package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.Bank;

public interface DaoBank {
	void createAccount(Bank b);
	Bank showBalance(int accNO);
	void deposit(int accNO, int amt);
	void withDraw(int accNO, int amt);
	void fundTransfer(int accNO, int accNOto, int amt);
	int checkAccno(int accno);
	int checkPass(String s);
	List<String> printTrans1(int accNO);


}
