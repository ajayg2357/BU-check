package com.capgemini.service;

import java.util.List;

import com.capgemini.model.Bank;

public interface BankService {
	void createAccount();

	Bank showBalance();

	void deposit();

	void withDrawal();

	void fundTransfer();

	List<String> printTransaction();

}


