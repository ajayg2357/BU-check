package com.capgemini.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.service.BankService;
import com.capgemini.service.BankServiceImpl;

public class Main {
	private static BankService service = new BankServiceImpl();
	private static Scanner  sc= new Scanner(System.in);
	public static void main(String[] args) {
		int option=0;
		do{
			System.out.println("Please Enter your Choice!!");
			System.out.println("Enter the choice \n 1. Create Account \n 2. Show Balance \n 3. Deposit \n 4. Withdrawal \n 5.Fund Transfer \n 6.Print Transactions");
			int choice = sc.nextInt();
			switch(choice)
			{
			case 1:
				service.createAccount();
				break;
			case 2:
				System.out.println(service.showBalance());
				break;
			case 3:
				service.deposit();
				break;
			case 4:
				service.withDrawal();
				break;
			case 5:
				service.fundTransfer();
				break;
			case 6:
				List<String> list = new ArrayList<String>();
				list=service.printTransaction();
				Iterator<String> itr = list.iterator();
			while(itr.hasNext())
			{
				System.out.println(itr.next());
			}
			default:
				System.out.println("Sorry!!You Have Opted an Invalid Option. Please Enter the Correct Option.\nThank you");
			
		}
		
System.out.println("Do you Wish to Continue : 1. CONTINUE \t 2.END");
		option= sc.nextInt();
		}
		while(option==1);
		}
}