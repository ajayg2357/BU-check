package com.capgemini.bank.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.bank.Beans.Customer;
//import com.capgemini.bank.Validator.Validate;
import com.capgemini.bank.DbUtil.DbUtil;

public class BankDaoImpl implements BankDao{
	
	private Connection con;

	@Override
	public Customer save(Customer c) {
		
		con = DbUtil.getConnection();
		try {
			PreparedStatement ps = con.prepareStatement("insert into bankdb values(?,?,?,?,?,?)");
			ps.setString(1, c.getFname());
			ps.setString(2, c.getLname());
			ps.setLong(3, c.getPhnum());
			ps.setLong(4, c.getAadharnum());
			ps.setLong(5, c.setAcountnum());
			ps.setDouble(6, c.getMoney());
			int i = ps.executeUpdate();
			if(i>0)
				System.out.println("Customer inserted Successfully!!!!");
		}
		catch(SQLException e1)
		{
			System.err.println("Something went wrong");
			e1.printStackTrace();
		}
		return null;
	}

	@Override
	public String showBal(long accnum) {
		
		con = DbUtil.getConnection();
		PreparedStatement ps;
		ResultSet rs;
		Customer c = new Customer();
		try {
			ps = con.prepareStatement("select money from bankdb where acnum = ?");
			ps.setLong(1, accnum);
			rs = ps.executeQuery();
			while(rs.next())
			{
				try {
				return Long.toString(rs.getLong(1));
				}
				catch(SQLException e1)
				{
					e1.printStackTrace();
				}
			}
		}
		catch(SQLException e1)
		{
			System.out.println("No such Account Number");
			e1.printStackTrace();
		}	
		return Double.toString(c.getMoney());
	}

	@Override
	public void deposit(long acnum, double money1) {
		
		double accBal;
		con = DbUtil.getConnection();
		PreparedStatement ps;
		try {
			 ps = con.prepareStatement("select money from bankdb where acnum = ?");
			ps.setLong(1, acnum);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				accBal = rs.getDouble(1);
					ps = con.prepareStatement("update bankdb set money = ? where acnum = ?");
					ps.setDouble(1, accBal+money1);
					ps.setLong(2, acnum);
					int i = ps.executeUpdate();
					if(i>0)
					{
						System.out.println("The Balance is: "+(accBal+money1));
					}				
			}
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void withdraw(long acnum1, double money) {
		double accBal;
		con = DbUtil.getConnection();
		PreparedStatement ps;
		try {
			 ps = con.prepareStatement("select money from bankdb where acnum = ?");
			ps.setLong(1, acnum1);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				accBal = rs.getDouble(1);
				if(accBal>=money)
				{
					ps = con.prepareStatement("update bankdb set money = ? where acnum = ?");
					ps.setDouble(1, accBal-money);
					ps.setLong(2, acnum1);
					int i = ps.executeUpdate();
					if(i>0)
					{
						System.out.println("The Balance is: "+(accBal-money));
					}
				}
				
			}
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public double transfer(long yaccnum, long raccnum, long amt) {
		double accBal;
		con = DbUtil.getConnection();
		PreparedStatement ps;
		try {
			ps = con.prepareStatement("select money from bankdb where acnum = ?");
			ps.setLong(1, yaccnum);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				accBal = rs.getDouble(1);
				if(accBal >= amt)
				{
					ps = con.prepareStatement("update bankdb set money = ? where acnum = ?");
					ps.setDouble(1, accBal-amt);
					ps.setLong(2, yaccnum);
					int i = ps.executeUpdate();
					if(i>0)
					{
						return accBal-amt;
					}
				}
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}	
}
