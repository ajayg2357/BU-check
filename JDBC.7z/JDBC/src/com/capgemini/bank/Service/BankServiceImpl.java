package com.capgemini.bank.Service;

import java.util.Scanner;
import com.capgemini.bank.Beans.Customer;
import com.capgemini.bank.Dao.BankDao;
import com.capgemini.bank.Dao.BankDaoImpl;
import com.capgemini.bank.Validator.Validate;

public class BankServiceImpl implements BankService {
	
	private static BankDao dao = new BankDaoImpl();
	private static Validate val = new Validate();
	private static Scanner sc = new Scanner(System.in);

	@Override
	public Customer saveCustomer() {

		Customer c = new Customer();
		System.out.println("Enter First Name:");
		String str = sc.next();
		if(val.name(str))
			c.setFname(str);
		else {
			System.out.println("Please start your First Name with capital letter");
			System.exit(0);
		}
		System.out.println("Enter Last Name:");
		String str1 = sc.next();
		if(val.name(str1))
			c.setLname(str1);
		else {
			System.out.println("Please start your Last Name with capital letter");
			System.exit(0);
		}
		System.out.println("Enter Phone Number:");
		long l1 = sc.nextLong();
		if(val.phnnum(l1))
			c.setPhnum(l1);
		else {
			System.out.println("Please enter valid 10 digit Phone Number");
			System.exit(0);
		}
		System.out.println("Enter Aadhar Number:");
		long l2 = sc.nextLong();
		if(val.aadnum(l2))
			c.setAadharnum(l2);
		else {
			System.out.println("Please enter valid 12 digit Aadhar Number");
			System.exit(0);
		}
		System.out.println("Enter money to be deposited");
		c.setMoney(sc.nextDouble());
		return dao.save(c);	
		
	}
	
	@Override
	public String showBalance(long accnum) {
		
		return dao.showBal(accnum);
	}


	@Override
	public void depositAmount(long acnum, double money1) {
		
		dao.deposit(acnum, money1);
	}

	@Override
	public void withdrawAmount(long acnum1, double money) {
		
			System.out.println("Enter amount to be withdrawn:");
			dao.withdraw(acnum1, money);
		
	}

	@Override
	public double fundTransfer(long yaccnum, long raccnum, long amt) {
		
			return dao.transfer(yaccnum, raccnum, amt);
		
	}

}
